<?php $__env->startSection('content'); ?>
  <pagina tamanho="12">
    <painel titulo="Lista de Artigos">
      <migalhas v-bind:lista="<?php echo e($listaMigalhas); ?>"></migalhas>


      <modallink tipo="link" nome="meuModalTeste" titulo="Criar" css=""></modallink>

      <tabela-lista
      v-bind:titulos="['#','Título','Descrição']"
      v-bind:itens="[[1,'PHP OO','Curso de PHP OO'],[2,'Vue JS','Curso de Vue JS']]"
      ordem="desc" ordemcol="1"
      criar="#criar" detalhe="#detalhe" editar="#editar" deletar="#deletar" token="7887522323"


      ></tabela-lista>

    </painel>

  </pagina>

  <modal nome="meuModalTeste">
    <painel titulo="Adicionar">
      <formulario css="" action="#" method="put" enctype="multipart/form-data" token="12345">

        <div class="form-group">
          <label for="titulo">Título</label>
          <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Título">
        </div>
        <div class="form-group">
          <label for="descricao">Descrição</label>
          <input type="text" class="form-control" id="descricao" name="descricao" placeholder="Descrição">
        </div>
        <button class="btn btn-info">Adicionar</button>
      </formulario>
    </painel>

  </modal>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>