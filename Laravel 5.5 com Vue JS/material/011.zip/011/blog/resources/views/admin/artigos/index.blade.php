@extends('layouts.app')

@section('content')
  <pagina tamanho="12">
    <painel titulo="Lista de Artigos">
      Teste de conteúdo..


    </painel>

  </pagina>
@endsection
